import json
import quart
import torch
import time
import quart_cors
from quart import request
import nest_asyncio
import requests
import openai  # Import the OpenAI package
from transformers import GPTNeoForCausalLM, GPT2Tokenizer
from llama_cpp import Llama

# Llama Model
llm = Llama(model_path="D:\\ggml-vicuna-7b-4bit\\ggml-vicuna-7b-4bit-rev1.bin")

def llama_generate(prompt, max_tokens=200):
    output = llm(prompt, max_tokens=max_tokens)
    return output['choices'][0]['text']

# GPT-Neo Model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = GPTNeoForCausalLM.from_pretrained('EleutherAI/gpt-neo-125M').to(device)
tokenizer = GPT2Tokenizer.from_pretrained('EleutherAI/gpt-neo-125M')

tokenizer.add_special_tokens({'pad_token': '[PAD]'})
model.config.pad_token_id = tokenizer.pad_token_id
model.cuda()

# Define GPT-4 generation function
def gpt4_generate(prompt, max_tokens=200):
    # Make sure to replace "YOUR_API_KEY" with your actual API key
    api_key = "replacekey"
    openai.api_key = api_key
    
    # Make a request to the GPT-4 API using the v1/chat/completions endpoint
    response = openai.ChatCompletion.create(
        model="gpt-4",  # Replace "gpt-4" with the appropriate engine name for GPT-4
        messages=[{"role": "system", "content": "ZZZ"},
                  {"role": "user", "content": prompt}],
        max_tokens=max_tokens
    )
    
    # Extract the generated text from the response
    generated_text = response["choices"][0]["message"]["content"]
    return generated_text

# Define a function to generate response using GPT-Neo
def gpt3_generate(model, tokenizer, chunk, max_length=2000, time_limit=50.0):
    start_time = time.time()

    inputs = tokenizer.encode(chunk, return_tensors='pt', truncation=True, max_length=512).to(device)
    attention_mask = inputs.ne(tokenizer.pad_token_id).float().to(device)
    outputs = model.generate(inputs, max_length=max_length, do_sample=True, max_time=time_limit, attention_mask=attention_mask)

    response = tokenizer.decode(outputs[0])
    end_time = time.time()

    return response, end_time - start_time

# Define a function to facilitate intercommunication between the models
async def intercommunication(prompt):
    # Generate response using Llama
    llama_response = llama_generate(prompt)
    
    # Generate response using GPT-Neo
    gpt_neo_response, _ = gpt3_generate(model, tokenizer, prompt)
    
    # Generate response using GPT-4 (ChatGPT plugin model)
    gpt4_response = gpt4_generate(prompt)
    
    # Generate response using ChatGPT plugin model
    chatgpt_plugin_response = await chatgpt_plugin_generate(prompt)
    
    # Combine the responses
    response = f"Llama: {llama_response}\nGPT-Neo: {gpt_neo_response}\nChatGPT: {gpt4_response}\nChatGPT Plugin: {chatgpt_plugin_response}\n"
    return response

# Keep track of TODOs.
# Does not persist if Python session is restarted.
_TODOS = {}

# Set the maximum length and time limit for the AI response
max_length = 823
time_limit = 14

nest_asyncio.apply()

app = quart_cors.cors(quart.Quart(__name__), allow_origin="https://chat.openai.com")

def send_message_to_intercom(username, message):
    print(f"Sending message to Intercom for user {username}: {message}")
    url = f"http://localhost:5000/intercom_ai/recieve/{username}"
    headers = {'Content-Type': 'application/json'}
    data = {
        "data": message
    }
    response = requests.post(url, headers=headers, data=json.dumps(data))
    if response.status_code == 200:
        print(f"Message sent successfully to {username}")
    else:
        print(f"Error sending message to {username}, status code: {response.status_code}")

@app.post("/todos/<string:username>")
async def add_todo(username):
    request_data = await request.get_json(force=True)
    if username not in _TODOS:
        _TODOS[username] = []
    _TODOS[username].append(request_data["todo"])
    return quart.Response(response='OK', status=200)

@app.get("/todos/<string:username>")
async def get_todos(username):
    return quart.Response(response=json.dumps(_TODOS.get(username, [])), status=200)

@app.delete("/todos/<string:username>")
async def delete_todo(username):
    request_data = await request.get_json(force=True)
    todo_idx = request_data["todo_idx"]
    if 0 <= todo_idx < len(_TODOS[username]):
        _TODOS[username].pop(todo_idx)
    return quart.Response(response='OK', status=200)

@app.get("/logo.png")
async def plugin_logo():
    filename = 'logo.png'
    return await quart.send_file(filename, mimetype='image/png')

@app.post("/intercom_ai_recieve/<string:username>")
async def intercom_ai_recieve(username):
    request_data = await request.get_json(force=True)
    data = request_data["data"]
    response = await intercommunication(data)
    send_message_to_intercom(username, response)
    return quart.Response(response='OK', status=200)

@app.post("/intercom_ai_send/<string:username>")
async def intercom_ai_send(username):
    request_data = await request.get_json(force=True)
    data = request_data["data"]
    send_message_to_intercom(username, data)
    return quart.Response(response='OK', status=200)

@app.get("/.well-known/ai-plugin.json")
async def plugin_manifest():
    host = request.headers['Host']
    with open("./.well-known/ai-plugin.json") as f:
        text = f.read()
        return quart.Response(text, mimetype="text/json")

@app.get("/openapi.yaml")
async def openapi_spec():
    host = request.headers['Host']
    with open("openapi.yaml") as f:
        text = f.read()
        return quart.Response(text, mimetype="text/yaml")

if __name__ == "__main__":
    app.run(port=5000)